﻿using System;
using System.IO;
namespace OddLines
{
    //using System.IO;

    public class OddLines
    {
        static void Main()
        {
            string inputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\OddLines\input.txt";
            string outputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\OddLines\output.txt";
            ExtractOddLines(inputFilePath, outputFilePath);


        }
        public static void ExtractOddLines(string inputFilePath, string outputFilePath)
        {
            StreamReader inputStreamReader = new StreamReader(inputFilePath);
            StreamWriter outputStreamWriter = new StreamWriter(outputFilePath);
            int counter = 0;
            using (inputStreamReader)
            {
                using (outputStreamWriter)
                {
                    while (inputStreamReader != null)
                    {

                        string line = inputStreamReader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        counter++;
                        if (counter % 2 == 0)
                        {
                            outputStreamWriter.WriteLine(line);
                        }
                        //line = inputStreamReader.ReadLine();
                    }
                }

            }

        }
    }

}

