﻿namespace WordCount
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    public class WordCount
    {
        static void Main()
        {
            string wordPath = @"C:\Users\Lenovo\source\repos\Streams and Files\WordCount\words.txt";
            string textPath = @"C:\Users\Lenovo\source\repos\Streams and Files\WordCount\text.txt";
            string outputPath = @"C:\Users\Lenovo\source\repos\Streams and Files\WordCount\output.txt";

            CalculateWordCounts(wordPath, textPath, outputPath);
        }

        public static void CalculateWordCounts(string wordsFilePath, string textFilePath, string outputFilePath)
        {
            StreamReader wordReader = new StreamReader(wordsFilePath);
            StreamReader textReader = new StreamReader(textFilePath);
            StreamWriter streamWriter = new StreamWriter(outputFilePath);
            string[] words = new string[] { };
            using (wordReader)
            {
                words = wordReader.ReadLine().Split().ToArray();

            }
            string line = "";
            StringBuilder sb = new StringBuilder();

            Dictionary<string, int> wordCounts = new Dictionary<string, int>();
            foreach (string word in words)
            {
                wordCounts.Add(word, 0);
            }
            using (textReader)
            {
                using (streamWriter)
                {
                    while (textReader != null)
                    {

                        line = textReader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }

                        char[] nextWord = line.Where(c => !char.IsPunctuation(c)).ToArray();
                        foreach (char c in nextWord)
                        {
                            sb.Append(c);
                        }

                        string[] wordArray = sb.ToString().ToLower().Split().ToArray();


                        foreach (string word in wordArray)
                        {
                            if (words.Contains(word))
                            {
                                wordCounts[word]++;
                            }
                        }
                        sb.Clear();
                    }
                    
                    foreach (var key in wordCounts.OrderByDescending(x => x.Value))
                    {
                        streamWriter.WriteLine($"{key.Key} - {key.Value}");
                    }
                }
            }
            

        }
    }
}
