﻿namespace LineNumbers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\LineNumbers\text.txt";
            string outputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\LineNumbers\output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            string[] lines = File.ReadAllLines(inputFilePath);
            int count = 0;
            List<string> outputLines = new List<string>();

            foreach (string line in lines)
            {
              
                count++;

              
                int countLetters = line.Count(char.IsLetter);
             
                int countSymbol = line.Count(char.IsPunctuation);
   
                string newLine = $"Line {count}: {line} ({countLetters})({countSymbol})";
               
                outputLines.Add(newLine);

            }
            File.WriteAllLines(outputFilePath, outputLines);

        }
    }
}
