﻿namespace MergeFiles
{
    using System;
    using System.IO;
    public class MergeFiles
    {
        static void Main()
        {
            var firstInputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\MergeFiles\input1.txt";
            var secondInputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\MergeFiles\input2.txt";
            var outputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\MergeFiles\output.txt";

            MergeTextFiles(firstInputFilePath, secondInputFilePath, outputFilePath);
        }

        public static void MergeTextFiles(string firstInputFilePath, string secondInputFilePath, string outputFilePath)
        {
            StreamReader reader = new StreamReader(firstInputFilePath);
            StreamReader readerSecond = new StreamReader(secondInputFilePath);
            StreamWriter streamWriter = new StreamWriter(outputFilePath);
            string lineOne = "";
            string lineTwo = "";
            using (reader)
            {
                using (readerSecond)
                {
                    using (streamWriter)
                    {
                        while (true)
                        {

                            if (lineOne != null)
                            {
                                lineOne = reader.ReadLine();
                                streamWriter.WriteLine(lineOne);
                            }
                            if (lineTwo != null)
                            {
                                lineTwo = readerSecond.ReadLine();
                                streamWriter.WriteLine(lineTwo);
                            }
                            if (lineOne == null && lineTwo == null)
                            {
                                break;
                            }

                        }
                    }
                    
                }
            }

        }
    }
}
