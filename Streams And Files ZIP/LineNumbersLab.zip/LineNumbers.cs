﻿namespace LineNumbers
{
    using System.IO;
    public class LineNumbers
    {
        static void Main()
        {
            string inputPath = @"C:\Users\Lenovo\source\repos\Streams and Files\LineNumbers\input.txt";
            string outputPath = @"C:\Users\Lenovo\source\repos\Streams and Files\LineNumbers\output.txt";

            RewriteFileWithLineNumbers(inputPath, outputPath);
        }

        public static void RewriteFileWithLineNumbers(string inputFilePath, string outputFilePath)
        {
            StreamReader streamReader = new StreamReader(inputFilePath);
            StreamWriter writer = new StreamWriter(outputFilePath);
            string line = "";
            int counter = 0;
            using (streamReader) 
            {
                using (writer)
                {
                    while (line != null)
                    {
                        
                        line = streamReader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        counter++;


                        writer.WriteLine($"{counter}. {line}");


                    }
                }


            }

        }
    }
}
