﻿namespace CopyBinaryFile
{
    using System;
    using System.Linq;
    using System.IO;

    public class CopyBinaryFile
    {
        static void Main()
        {
            string inputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\CopyBinaryFile\copyMe.png";
            string outputFilePath = @"C:\Users\Lenovo\source\repos\Streams and Files\CopyBinaryFile\copyMe-copy.png";

            CopyFile(inputFilePath, outputFilePath);
        }

        public static void CopyFile(string inputFilePath, string outputFilePath)
        {
            FileStream reader = new FileStream(inputFilePath, FileMode.Open);
            FileStream writer = new FileStream(outputFilePath, FileMode.Create);
            using (reader)
            {
                using (writer)
                {
                    while (true)
                    {
                        byte[] buffer = new byte[4096];
                        int countBytes = reader.Read(buffer, 0, buffer.Length);
                        if (countBytes == 0)
                        {
                            break;
                        }


                        writer.Write(buffer, 0, countBytes);
                    }
                }
            }
        }
    }
}
